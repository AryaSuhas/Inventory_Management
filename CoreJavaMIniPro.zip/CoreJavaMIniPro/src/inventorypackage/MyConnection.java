package inventorypackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

    public static Connection getMyConnection() {
        Connection con = null;
        try {
            System.out.println("Loading driver...");
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println("Connecting to database...");
            String url = "jdbc:mysql://localhost:3306/inventorydb"; // change DB name if needed
            String username = "root"; // check username
            String password = "123456789"; // check password

            con = DriverManager.getConnection(url, username, password);
            System.out.println("✅ Connection successful!");

        } catch (ClassNotFoundException e) {
            System.out.println("❌ JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("❌ SQL Error: " + e.getMessage());
        }

        return con;
    }
}
