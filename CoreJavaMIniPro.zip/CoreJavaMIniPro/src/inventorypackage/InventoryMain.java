package inventorypackage;

import java.util.Scanner;

public class InventoryMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        InventoryDAO dao = new InventoryDAO();

        while (true) {
            System.out.println("\n========= INVENTORY MANAGEMENT SYSTEM =========");
            System.out.println("1. Create Table (if not exists)");
            System.out.println("2. Add Item");
            System.out.println("3. Display All Items");
            System.out.println("4. Update Item by ID");
            System.out.println("5. Delete Item by ID");
            System.out.println("6. Find Item by ID");
            System.out.println("7. Display Low Stock Items");
            System.out.println("8. Sort by Price");
            System.out.println("9. Total Inventory Value");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    dao.createTable();
                    break;

                case 2:
                    sc.nextLine();
                    System.out.print("Enter Item Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Quantity: ");
                    int qty = sc.nextInt();
                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Enter Category: ");
                    String cat = sc.nextLine();
                    dao.addItem(new Inventory(name, qty, price, cat));
                    break;

                case 3:
                    dao.displayAll();
                    break;

                case 4:
                    System.out.print("Enter Item ID to Update: ");
                    int idu = sc.nextInt();
                    System.out.print("Enter New Quantity: ");
                    int uq = sc.nextInt();
                    System.out.print("Enter New Price: ");
                    double up = sc.nextDouble();
                    dao.updateItem(idu, uq, up);
                    break;

                case 5:
                    System.out.print("Enter Item ID to Delete: ");
                    int idd = sc.nextInt();
                    dao.deleteItem(idd);
                    break;

                case 6:
                    System.out.print("Enter Item ID to Search: ");
                    int ids = sc.nextInt();
                    dao.findById(ids);
                    break;

                case 7:
                    System.out.print("Enter Stock Threshold: ");
                    int th = sc.nextInt();
                    dao.displayLowStock(th);
                    break;

                case 8:
                    dao.sortByPrice();
                    break;

                case 9:
                    dao.totalInventoryValue();
                    break;

                case 10:
                    System.out.println("Exiting...");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println(" Invalid choice!");
            }
        }
    }
}
