package inventorypackage;

import java.sql.*;

public class InventoryDAO {
    Connection con = MyConnection.getMyConnection();
    
    public InventoryDAO() {
        this.con = MyConnection.getMyConnection();
    }

    // 1. Create table if not exists
    public void createTable() {
        try {
            String sql = """
                CREATE TABLE IF NOT EXISTS inventory (
                    item_id INT PRIMARY KEY AUTO_INCREMENT,
                    item_name VARCHAR(100) NOT NULL,
                    quantity INT NOT NULL,
                    price DOUBLE NOT NULL,
                    category VARCHAR(50)
                )
                """;
            PreparedStatement ps = con.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println(" Table 'inventory' created or already exists!");
        } catch (Exception e) {
            System.out.println(e.getMessage());       
          }
    }

    // 2. Add item
    public void addItem(Inventory inv) {
        try {
            String sql = "INSERT INTO inventory(item_name, quantity, price, category) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, inv.getItemName());
            ps.setInt(2, inv.getQuantity());
            ps.setDouble(3, inv.getPrice());
            ps.setString(4, inv.getCategory());
            ps.executeUpdate();
            System.out.println(" Item added successfully!");
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    // 3. Display all
    public void displayAll() {
        try {
            String sql = "SELECT * FROM inventory";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            System.out.println("\n=== INVENTORY LIST ===");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getInt(3) +
                                   " | " + rs.getDouble(4) + " | " + rs.getString(5));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    // 4. Update by ID
    public void updateItem(int id, int qty, double price) {
        try {
            String sql = "UPDATE inventory SET quantity=?, price=? WHERE item_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, qty);
            ps.setDouble(2, price);
            ps.setInt(3, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println(" Item updated successfully!");
            else
                System.out.println("⚠️ Item not found!");
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    // 5. Delete by ID
    public void deleteItem(int id) {
        try {
            String sql = "DELETE FROM inventory WHERE item_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println(" Item deleted successfully!");
            else
                System.out.println(" Item not found!");
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    // 6. Find by ID
    public void findById(int id) {
        try {
            String sql = "SELECT * FROM inventory WHERE item_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("Item Found → " + rs.getString("item_name") +
                                   " | Qty: " + rs.getInt("quantity") +
                                   " | Price: " + rs.getDouble("price"));
            } else {
                System.out.println(" Item not found!");
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    // 7. Display Low Stock Items
    public void displayLowStock(int threshold) {
        try {
            String sql = "SELECT * FROM inventory WHERE quantity < ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, threshold);
            ResultSet rs = ps.executeQuery();
            System.out.println("\n LOW STOCK ITEMS (< " + threshold + "):");
            while (rs.next()) {
                System.out.println(rs.getString("item_name") + " | Qty: " + rs.getInt("quantity"));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    // 8. Sort by Price
    public void sortByPrice() {
        try {
            String sql = "SELECT * FROM inventory ORDER BY price DESC";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            System.out.println("\n=== INVENTORY SORTED BY PRICE ===");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getDouble(4));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    // 9. Total Inventory Value
    public void totalInventoryValue() {
        try {
            String sql = "SELECT SUM(quantity * price) AS total_value FROM inventory";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("\n Total Inventory Value: ₹" + rs.getDouble("total_value"));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }
}
