package inventorypackage;

public class TestConnection {
    public static void main(String[] args) {
        MyConnection.getMyConnection();
    }
}
